import HospitalAdminNew from './HospitalAdminNew';

export default HospitalAdminNew;
